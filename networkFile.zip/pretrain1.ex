defI:-
defT:-
min:1
max:4
grace:0.5
;
name: WhiteFemFeatPredName1
I:	
(targPerson)                                                                                                
 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0
(hairLength)    
 1 0
(femFacFeat)    
 1 0
(skinColor)    
 1 0
T:	
(femCatOUT)    
 1 0
;
name: WhiteFemFeatPredName2
I:	
(targPerson)                                                                                                
 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0
(hairLength)    
 1 0
(femFacFeat)    
 1 0
(skinColor)    
 1 0
T:	
(femCatOUT)    
 1 0
;
name: WhiteFemFeatPredName3
I:	
(targPerson)                                                                                                
 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 1
(hairLength)    
 1 0
(femFacFeat)    
 1 0
(skinColor)    
 1 0
T:	
(femCatOUT)    
 1 0
;
name: WhiteFemFeatPredName4
I:	
(targPerson)                                                                                                
 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 1 0 0 0 0 0
(hairLength)    
 1 0
(femFacFeat)    
 1 0
(skinColor)    
 1 0
T:	
(femCatOUT)    
 1 0
;
name: WhiteFemFeatPredName5
I:	
(targPerson)                                                                                                
 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0
(hairLength)    
 1 0
(femFacFeat)    
 1 0
(skinColor)    
 1 0
T:	
(femCatOUT)    
 1 0
;
name: WhiteFemFeatPredName6
I:	
(targPerson)                                                                                                
 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0
(hairLength)    
 1 0
(femFacFeat)    
 1 0
(skinColor)    
 1 0
T:	
(femCatOUT)    
 1 0
;
name: WhiteFemFeatPredName7
I:	
(targPerson)                                                                                                
 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0
(hairLength)    
 1 0
(femFacFeat)    
 1 0
(skinColor)    
 1 0
T:	
(femCatOUT)    
 1 0
;
name: WhiteFemFeatPredName8
I:	
(targPerson)                                                                                                
 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 1 0 0 0 0 0 0
(hairLength)    
 1 0
(femFacFeat)    
 1 0
(skinColor)    
 1 0
T:	
(femCatOUT)    
 1 0
;
name: WhiteFemFeatPredName9
I:	
(targPerson)                                                                                                
 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 1 0 0 0 0
(hairLength)    
 1 0
(femFacFeat)    
 1 0
(skinColor)    
 1 0
T:	
(femCatOUT)    
 1 0
;
name: WhiteFemFeatPredName10
I:	
(targPerson)                                                                                                
 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0
(hairLength)    
 1 0
(femFacFeat)    
 1 0
(skinColor)    
 1 0
T:	
(femCatOUT)    
 1 0
;
name: WhiteFemFeatPredName11
I:	
(targPerson)                                                                                                
 0 0 0 0 0 0 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0
(hairLength)    
 1 0
(femFacFeat)    
 1 0
(skinColor)    
 1 0
T:	
(femCatOUT)    
 1 0
;
name: WhiteFemFeatPredName12
I:	
(targPerson)                                                                                                
 0 0 0 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0
(hairLength)    
 1 0
(femFacFeat)    
 1 0
(skinColor)    
 1 0
T:	
(femCatOUT)    
 1 0
;
name: WhiteFemFeatPredName13
I:	
(targPerson)                                                                                                
 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0
(hairLength)    
 1 0
(femFacFeat)    
 1 0
(skinColor)    
 1 0
T:	
(femCatOUT)    
 1 0
;
name: WhiteFemFeatPredName14
I:	
(targPerson)                                                                                                
 0 0 0 0 0 0 0 0 0 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0
(hairLength)    
 1 0
(femFacFeat)    
 1 0
(skinColor)    
 1 0
T:	
(femCatOUT)    
 1 0
;
name: WhiteFemFeatPredName15
I:	
(targPerson)                                                                                                
 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0
(hairLength)    
 1 0
(femFacFeat)    
 1 0
(skinColor)    
 1 0
T:	
(femCatOUT)    
 1 0
;
name: WhiteFemFeatPredName16
I:	
(targPerson)                                                                                                
 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0
(hairLength)    
 1 0
(femFacFeat)    
 1 0
(skinColor)    
 1 0
T:	
(femCatOUT)    
 1 0
;
name: WhiteFemFeatPredName17
I:	
(targPerson)                                                                                                
 0 0 0 0 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0
(hairLength)    
 1 0
(femFacFeat)    
 1 0
(skinColor)    
 1 0
T:	
(femCatOUT)    
 1 0
;
name: WhiteFemFeatPredName18
I:	
(targPerson)                                                                                                
 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0
(hairLength)    
 1 0
(femFacFeat)    
 1 0
(skinColor)    
 1 0
T:	
(femCatOUT)    
 1 0
;
name: WhiteFemFeatPredName19
I:	
(targPerson)                                                                                                
 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0
(hairLength)    
 1 0
(femFacFeat)    
 1 0
(skinColor)    
 1 0
T:	
(femCatOUT)    
 1 0
;
name: WhiteFemFeatPredName20
I:	
(targPerson)                                                                                                
 0 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0
(hairLength)    
 1 0
(femFacFeat)    
 1 0
(skinColor)    
 1 0
T:	
(femCatOUT)    
 1 0
;
name: WhiteFemFeatPredName21
I:	
(targPerson)                                                                                                
 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 1 0 0 0
(hairLength)    
 1 0
(femFacFeat)    
 1 0
(skinColor)    
 1 0
T:	
(femCatOUT)    
 1 0
;
name: WhiteFemFeatPredName22
I:	
(targPerson)                                                                                                
 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0
(hairLength)    
 1 0
(femFacFeat)    
 1 0
(skinColor)    
 1 0
T:	
(femCatOUT)    
 1 0
;
name: WhiteFemFeatPredName23
I:	
(targPerson)                                                                                                
 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0
(hairLength)    
 1 0
(femFacFeat)    
 1 0
(skinColor)    
 1 0
T:	
(femCatOUT)    
 1 0
;
name: WhiteFemFeatPredName24
I:	
(targPerson)                                                                                                
 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0
(hairLength)    
 1 0
(femFacFeat)    
 1 0
(skinColor)    
 1 0
T:	
(femCatOUT)    
 1 0
;
name: WhiteFemFeatPredName25
I:	
(targPerson)                                                                                                
 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0
(hairLength)    
 1 0
(femFacFeat)    
 1 0
(skinColor)    
 1 0
T:	
(femCatOUT)    
 1 0
;
name: WhiteFemFeatPredName26
I:	
(targPerson)                                                                                                
 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 1 0
(hairLength)    
 1 0
(femFacFeat)    
 1 0
(skinColor)    
 1 0
T:	
(femCatOUT)    
 1 0
;
name: NamePredWhiteFemFeat1
I:	
(femCat)    
 1 0
T:	
(targPersonOUT)                                                                                                
 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0
(hairLengthOUT)    
 1 0
(femFacFeatOUT)    
 1 0
(skinColorOUT)    
 1 0
;
name: NamePredWhiteFemFeat2
I:	
(femCat)    
 1 0
T:	
(targPersonOUT)                                                                                                
 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0
(hairLengthOUT)    
 1 0
(femFacFeatOUT)    
 1 0
(skinColorOUT)    
 1 0
;
name: NamePredWhiteFemFeat3
I:	
(femCat)    
 1 0
T:	
(targPersonOUT)                                                                                                
 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 1
(hairLengthOUT)    
 1 0
(femFacFeatOUT)    
 1 0
(skinColorOUT)    
 1 0
;
name: NamePredWhiteFemFeat4
I:	
(femCat)    
 1 0
T:	
(targPersonOUT)                                                                                                
 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 1 0 0 0 0 0
(hairLengthOUT)    
 1 0
(femFacFeatOUT)    
 1 0
(skinColorOUT)    
 1 0
;
name: NamePredWhiteFemFeat5
I:	
(femCat)    
 1 0
T:	
(targPersonOUT)                                                                                                
 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0
(hairLengthOUT)    
 1 0
(femFacFeatOUT)    
 1 0
(skinColorOUT)    
 1 0
;
name: NamePredWhiteFemFeat6
I:	
(femCat)    
 1 0
T:	
(targPersonOUT)                                                                                                
 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0
(hairLengthOUT)    
 1 0
(femFacFeatOUT)    
 1 0
(skinColorOUT)    
 1 0
;
name: NamePredWhiteFemFeat7
I:	
(femCat)    
 1 0
T:	
(targPersonOUT)                                                                                                
 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0
(hairLengthOUT)    
 1 0
(femFacFeatOUT)    
 1 0
(skinColorOUT)    
 1 0
;
name: NamePredWhiteFemFeat8
I:	
(femCat)    
 1 0
T:	
(targPersonOUT)                                                                                                
 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 1 0 0 0 0 0 0
(hairLengthOUT)    
 1 0
(femFacFeatOUT)    
 1 0
(skinColorOUT)    
 1 0
;
name: NamePredWhiteFemFeat9
I:	
(femCat)    
 1 0
T:	
(targPersonOUT)                                                                                                
 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 1 0 0 0 0
(hairLengthOUT)    
 1 0
(femFacFeatOUT)    
 1 0
(skinColorOUT)    
 1 0
;
name: NamePredWhiteFemFeat10
I:	
(femCat)    
 1 0
T:	
(targPersonOUT)                                                                                                
 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0
(hairLengthOUT)    
 1 0
(femFacFeatOUT)    
 1 0
(skinColorOUT)    
 1 0
;
name: NamePredWhiteFemFeat11
I:	
(femCat)    
 1 0
T:	
(targPersonOUT)                                                                                                
 0 0 0 0 0 0 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0
(hairLengthOUT)    
 1 0
(femFacFeatOUT)    
 1 0
(skinColorOUT)    
 1 0
;
name: NamePredWhiteFemFeat12
I:	
(femCat)    
 1 0
T:	
(targPersonOUT)                                                                                                
 0 0 0 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0
(hairLengthOUT)    
 1 0
(femFacFeatOUT)    
 1 0
(skinColorOUT)    
 1 0
;
name: NamePredWhiteFemFeat13
I:	
(femCat)    
 1 0
T:	
(targPersonOUT)                                                                                                
 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0
(hairLengthOUT)    
 1 0
(femFacFeatOUT)    
 1 0
(skinColorOUT)    
 1 0
;
name: NamePredWhiteFemFeat14
I:	
(femCat)    
 1 0
T:	
(targPersonOUT)                                                                                                
 0 0 0 0 0 0 0 0 0 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0
(hairLengthOUT)    
 1 0
(femFacFeatOUT)    
 1 0
(skinColorOUT)    
 1 0
;
name: NamePredWhiteFemFeat15
I:	
(femCat)    
 1 0
T:	
(targPersonOUT)                                                                                                
 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0
(hairLengthOUT)    
 1 0
(femFacFeatOUT)    
 1 0
(skinColorOUT)    
 1 0
;
name: NamePredWhiteFemFeat16
I:	
(femCat)    
 1 0
T:	
(targPersonOUT)                                                                                                
 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0
(hairLengthOUT)    
 1 0
(femFacFeatOUT)    
 1 0
(skinColorOUT)    
 1 0
;
name: NamePredWhiteFemFeat17
I:	
(femCat)    
 1 0
T:	
(targPersonOUT)                                                                                                
 0 0 0 0 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0
(hairLengthOUT)    
 1 0
(femFacFeatOUT)    
 1 0
(skinColorOUT)    
 1 0
;
name: NamePredWhiteFemFeat18
I:	
(femCat)    
 1 0
T:	
(targPersonOUT)                                                                                                
 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0
(hairLengthOUT)    
 1 0
(femFacFeatOUT)    
 1 0
(skinColorOUT)    
 1 0
;
name: NamePredWhiteFemFeat19
I:	
(femCat)    
 1 0
T:	
(targPersonOUT)                                                                                                
 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0
(hairLengthOUT)    
 1 0
(femFacFeatOUT)    
 1 0
(skinColorOUT)    
 1 0
;
name: NamePredWhiteFemFeat20
I:	
(femCat)    
 1 0
T:	
(targPersonOUT)                                                                                                
 0 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0
(hairLengthOUT)    
 1 0
(femFacFeatOUT)    
 1 0
(skinColorOUT)    
 1 0
;
name: NamePredWhiteFemFeat21
I:	
(femCat)    
 1 0
T:	
(targPersonOUT)                                                                                                
 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 1 0 0 0
(hairLengthOUT)    
 1 0
(femFacFeatOUT)    
 1 0
(skinColorOUT)    
 1 0
;
name: NamePredWhiteFemFeat22
I:	
(femCat)    
 1 0
T:	
(targPersonOUT)                                                                                                
 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0
(hairLengthOUT)    
 1 0
(femFacFeatOUT)    
 1 0
(skinColorOUT)    
 1 0
;
name: NamePredWhiteFemFeat23
I:	
(femCat)    
 1 0
T:	
(targPersonOUT)                                                                                                
 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0
(hairLengthOUT)    
 1 0
(femFacFeatOUT)    
 1 0
(skinColorOUT)    
 1 0
;
name: NamePredWhiteFemFeat24
I:	
(femCat)    
 1 0
T:	
(targPersonOUT)                                                                                                
 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0
(hairLengthOUT)    
 1 0
(femFacFeatOUT)    
 1 0
(skinColorOUT)    
 1 0
;
name: NamePredWhiteFemFeat25
I:	
(femCat)    
 1 0
T:	
(targPersonOUT)                                                                                                
 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0
(hairLengthOUT)    
 1 0
(femFacFeatOUT)    
 1 0
(skinColorOUT)    
 1 0
;
name: NamePredWhiteFemFeat26
I:	
(femCat)    
 1 0
T:	
(targPersonOUT)                                                                                                
 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 1 0
(hairLengthOUT)    
 1 0
(femFacFeatOUT)    
 1 0
(skinColorOUT)    
 1 0
;
name: BlackMaleFeatPredName1
I:	
(targPerson)                                                                                                
 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0
(hairLength)    
 0 1
(femFacFeat)    
 0 1
(skinColor)    
 0 1
T:	
(femCatOUT)    
 0 1
;
name: BlackMaleFeatPredName2
I:	
(targPerson)                                                                                                
 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0
(hairLength)    
 0 1
(femFacFeat)    
 0 1
(skinColor)    
 0 1
T:	
(femCatOUT)    
 0 1
;
name: BlackMaleFeatPredName3
I:	
(targPerson)                                                                                                
 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 1 0 0 0 0 0 0 0 0
(hairLength)    
 0 1
(femFacFeat)    
 0 1
(skinColor)    
 0 1
T:	
(femCatOUT)    
 0 1
;
name: BlackMaleFeatPredName4
I:	
(targPerson)                                                                                                
 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0
(hairLength)    
 0 1
(femFacFeat)    
 0 1
(skinColor)    
 0 1
T:	
(femCatOUT)    
 0 1
;
name: BlackMaleFeatPredName5
I:	
(targPerson)                                                                                                
 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0
(hairLength)    
 0 1
(femFacFeat)    
 0 1
(skinColor)    
 0 1
T:	
(femCatOUT)    
 0 1
;
name: BlackMaleFeatPredName6
I:	
(targPerson)                                                                                                
 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0
(hairLength)    
 0 1
(femFacFeat)    
 0 1
(skinColor)    
 0 1
T:	
(femCatOUT)    
 0 1
;
name: BlackMaleFeatPredName7
I:	
(targPerson)                                                                                                
 0 0 0 0 0 0 0 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0
(hairLength)    
 0 1
(femFacFeat)    
 0 1
(skinColor)    
 0 1
T:	
(femCatOUT)    
 0 1
;
name: BlackMaleFeatPredName8
I:	
(targPerson)                                                                                                
 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 1 0 0
(hairLength)    
 0 1
(femFacFeat)    
 0 1
(skinColor)    
 0 1
T:	
(femCatOUT)    
 0 1
;
name: BlackMaleFeatPredName9
I:	
(targPerson)                                                                                                
 0 0 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0
(hairLength)    
 0 1
(femFacFeat)    
 0 1
(skinColor)    
 0 1
T:	
(femCatOUT)    
 0 1
;
name: BlackMaleFeatPredName10
I:
(targPerson)                                                                                                
 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0
(hairLength)    
 0 1
(femFacFeat)    
 0 1
(skinColor)    
 0 1
T:	
(femCatOUT)    
 0 1
;
name: BlackMaleFeatPredName11
I:	
(targPerson)                                                                                                
 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0
(hairLength)    
 0 1
(femFacFeat)    
 0 1
(skinColor)    
 0 1
T:	
(femCatOUT)    
 0 1
;
name: BlackMaleFeatPredName12
I:	
(targPerson)                                                                                                
 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0
(hairLength)    
 0 1
(femFacFeat)    
 0 1
(skinColor)    
 0 1
T:	
(femCatOUT)    
 0 1
;
name: BlackMaleFeatPredName13
I:	
(targPerson)                                                                                                
 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0
(hairLength)    
 0 1
(femFacFeat)    
 0 1
(skinColor)    
 0 1
T:	
(femCatOUT)    
 0 1
;
name: BlackMaleFeatPredName14
I:	
(targPerson)                                                                                                
 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0
(hairLength)    
 0 1
(femFacFeat)    
 0 1
(skinColor)    
 0 1
T:	
(femCatOUT)    
 0 1
;
name: NamePredBlackMaleFeat1
I:	
(femCat)    
 0 1
T:	
(targPersonOUT)                                                                                                
 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0
(hairLengthOUT)    
 0 1
(femFacFeatOUT)    
 0 1
(skinColorOUT)    
 0 1
;
name: NamePredBlackMaleFeat2
I:	
(femCat)    
 0 1
T:	
(targPersonOUT)                                                                                                
 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0
(hairLengthOUT)    
 0 1
(femFacFeatOUT)    
 0 1
(skinColorOUT)    
 0 1
;
name: NamePredBlackMaleFeat3
I:	
(femCat)    
 0 1
T:	
(targPersonOUT)                                                                                                
 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 1 0 0 0 0 0 0 0 0
(hairLengthOUT)    
 0 1
(femFacFeatOUT)    
 0 1
(skinColorOUT)    
 0 1
;
name: NamePredBlackMaleFeat4
I:	
(femCat)    
 0 1
T:	
(targPersonOUT)                                                                                                
 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0
(hairLengthOUT)    
 0 1
(femFacFeatOUT)    
 0 1
(skinColorOUT)    
 0 1
;
name: NamePredBlackMaleFeat5
I:	
(femCat)    
 0 1
T:	
(targPersonOUT)                                                                                                
 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0
(hairLengthOUT)    
 0 1
(femFacFeatOUT)    
 0 1
(skinColorOUT)    
 0 1
;
name: NamePredBlackMaleFeat6
I:	
(femCat)    
 0 1
T:	
(targPersonOUT)                                                                                                
 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0
(hairLengthOUT)    
 0 1
(femFacFeatOUT)    
 0 1
(skinColorOUT)    
 0 1
;
name: NamePredBlackMaleFeat7
I:	
(femCat)    
 0 1
T:	
(targPersonOUT)                                                                                                
 0 0 0 0 0 0 0 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0
(hairLengthOUT)    
 0 1
(femFacFeatOUT)    
 0 1
(skinColorOUT)    
 0 1
;
name: NamePredBlackMaleFeat8
I:	
(femCat)    
 0 1
T:	
(targPersonOUT)                                                                                                
 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 1 0 0
(hairLengthOUT)    
 0 1
(femFacFeatOUT)    
 0 1
(skinColorOUT)    
 0 1
;
name: NamePredBlackMaleFeat9
I:	
(femCat)    
 0 1
T:	
(targPersonOUT)                                                                                                
 0 0 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0
(hairLengthOUT)    
 0 1
(femFacFeatOUT)    
 0 1
(skinColorOUT)    
 0 1
;
name: NamePredBlackMaleFeat10
I:	
(femCat)    
 0 1
T:	
(targPersonOUT)                                                                                                
 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0
(hairLengthOUT)    
 0 1
(femFacFeatOUT)    
 0 1
(skinColorOUT)    
 0 1
;
name: NamePredBlackMaleFeat11
I:	
(femCat)    
 0 1
T:	
(targPersonOUT)                                                                                                
 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0
(hairLengthOUT)    
 0 1
(femFacFeatOUT)    
 0 1
(skinColorOUT)    
 0 1
;
name: NamePredBlackMaleFeat12
I:	
(femCat)    
 0 1
T:	
(targPersonOUT)                                                                                                
 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0
(hairLengthOUT)    
 0 1
(femFacFeatOUT)    
 0 1
(skinColorOUT)    
 0 1
;
name: NamePredBlackMaleFeat13
I:	
(femCat)    
 0 1
T:	
(targPersonOUT)                                                                                                
 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0
(hairLengthOUT)    
 0 1
(femFacFeatOUT)    
 0 1
(skinColorOUT)    
 0 1
;
name: NamePredBlackMaleFeat14
I:	
(femCat)    
 0 1
T:	
(targPersonOUT)                                                                                                
 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0
(hairLengthOUT)    
 0 1
(femFacFeatOUT)    
 0 1
(skinColorOUT)    
 0 1
;