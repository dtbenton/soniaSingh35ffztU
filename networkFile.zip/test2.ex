defI:-
defT:-
min:1
max:4
grace:0.5
;
name: WhiteFemFeatPredName1
I:	
(targPerson)                                                                                                
 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0
(hairLength)    
 1 0
(femFacFeat)    
 1 0
(skinColor)    
 1 0
T:	
(femCatOUT)    
 1 0
;
name: WhiteFemFeatPredName2
I:	
(targPerson)                                                                                                
 0 0 0 0 0 0 0 0 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0
(hairLength)    
 1 0
(femFacFeat)    
 1 0
(skinColor)    
 1 0
T:	
(femCatOUT)    
 1 0
;
name: NamePredWhiteFemFeat1
I:	
(femCat)    
 1 0
T:	
(targPersonOUT)                                                                                                
 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0
(hairLengthOUT)    
 1 0
(femFacFeatOUT)    
 1 0
(skinColorOUT)    
 1 0
;
name: NamePredWhiteFemFeat2
I:	
(femCat)    
 1 0
T:	
(targPersonOUT)                                                                                                
 0 0 0 0 0 0 0 0 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0
(hairLengthOUT)    
 1 0
(femFacFeatOUT)    
 1 0
(skinColorOUT)    
 1 0
;
name: BlackFemFeatPredName1
I:	
(targPerson)                                                                                                
 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0
(hairLength)    
 0 1
(femFacFeat)    
 1 0
(skinColor)    
 0 1
T:	
(femCatOUT)    
 1 0
;
name: BlackFemFeatPredName2
I:	
(targPerson)                                                                                                
 0 0 0 0 0 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0
(hairLength)    
 0 1
(femFacFeat)    
 1 0
(skinColor)    
 0 1
T:	
(femCatOUT)    
 1 0
;
name: NamePredBlackFemFeat1
I:	
(femCat)    
 1 0
T:	
(targPersonOUT)                                                                                                
 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0
(hairLengthOUT)    
 0 1
(femFacFeatOUT)    
 1 0
(skincolorOUT)    
 0 1
;
name: NamePredBlackFemFeat2
I:	
(femCat)    
 1 0
T:	
(targPersonOUT)                                                                                                
 0 0 0 0 0 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0
(hairLengthOUT)    
 0 1
(femFacFeatOUT)    
 1 0
(skinColorOUT)    
 0 1
;
name: BlackMaleFeatPredName1
I:	
(targPerson)                                                                                                
 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0
(hairLength)    
 0 1
(femFacFeat)    
 0 1
(skinColor)    
 0 1
T:	
(femCatOUT)    
 0 1
;
name: BlackMaleFeatPredName2
I:	
(targPerson)                                                                                                
 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0
(hairLength)    
 0 1
(femFacFeat)    
 0 1
(skinColor)    
 0 1
T:	
(femCatOUT)    
 0 1
;
name: NamePredBlackMaleFeat1
I:	
(femCat)    
 0 1
T:	
(targPersonOUT)                                                                                                
 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0
(hairLengthOUT)    
 0 1
(femFacFeatOUT)    
 0 1
(skinColorOUT)    
 0 1
;
name: NamePredBlackMaleFeat2
I:	
(femCat)    
 0 1
T:	
(targPersonOUT)                                                                                                
 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0
(hairLengthOUT)    
 0 1
(femFacFeatOUT)    
 0 1
(skinColorOUT)    
 0 1
;