##############################
# Lei, Benton, & Singh Model #
##############################s

##################################
# STIMLI FOR NETWORK SIMULATIONS #
##################################
# set the working directory
setwd("C:/Users/detbe/OneDrive/Desktop/leiBentonSinghModle")

###################################
# GENERATE VECTORS FOR SIMULATION #
###################################
n = 12
vector_set = diag(48)

# randomize stimuli
vector_set = vector_set[sample(1:nrow(vector_set)),]
vector_set = as.data.frame(vector_set)

##########################################
## Create people_features matrix ##
##########################################
white_predom_fem_pretrain = vector_set[1:30, ] # 75% of the examples are white, female, with long hair
white_predom_fem_test = vector_set[31:33,]

black_predom_fem_pretrain = vector_set[34:38,] # 24.75% of the examples it experiences are black, female, with short hair
black_predom_fem_test = vector_set[39:41,]

black_predom_male_pretrain = vector_set[42:45,] # 0.25% of the examples it experiences are black, male, with short hair
black_predom_male_test = vector_set[46:48,] 

# remove row names of 'people_features_1'
names(white_predom_fem_pretrain)  = NULL
rownames(white_predom_fem_pretrain) = NULL
colnames(white_predom_fem_pretrain) <- NULL


names(black_predom_fem_pretrain)  = NULL
rownames(black_predom_fem_pretrain) = NULL
colnames(black_predom_fem_pretrain) <- NULL


names(black_predom_male_pretrain)  = NULL
rownames(black_predom_male_pretrain) = NULL
colnames(black_predom_male_pretrain) <- NULL

names(white_predom_fem_test)  = NULL
rownames(white_predom_fem_test) = NULL
colnames(white_predom_fem_test) <- NULL


names(black_predom_fem_test)  = NULL
rownames(black_predom_fem_test) = NULL
colnames(black_predom_fem_test) <- NULL


names(black_predom_male_test)  = NULL
rownames(black_predom_male_test) = NULL
colnames(black_predom_male_test) <- NULL

# set seed, shuffle rows of people_features, and get the resulting dimension
set.seed(2023)



################
## SKIN COLOR ##
################

skinColor = data.frame(x = c('0 1', '1 0'))
names(skinColor) = NULL


# White: '1 0' 
# Black: '0 1'


#################
## HAIR LENGTH ##
#################

hairLength = data.frame(x = c('0 1', '1 0'))
names(hairLength) = NULL


# Long: '1 0' 
# Short: '0 1'


############################
## FEMALE FACIAL FEATURES ##
############################

femFacFeat = data.frame(x = c('0 1', '1 0'))
names(femFacFeat) = NULL


# Feminine: '1 0' 
# Masculine: '0 1'



###########################
## FEMALE CATEGORIZATION ##
###########################

femCat = data.frame(x = c('0 1', '1 0'))
names(femCat) = NULL


# Female: '1' 
# Male: '0'


#################
## PRETRAINING ##
#################
l = 1 
k = 1
m = 1
n = 1
o = 1
p = 1


sink('pretrain.ex')
cat(paste("defI:-", "\n", sep=""))
cat(paste("defT:-", "\n", sep=""))
cat(paste(";", "\n", sep=""))
# features predicting femCat
for(i in 1:nrow(white_predom_fem_pretrain)){
  cat(paste("name: WhiteFemFeatPredName", l, "\n", sep=""))
  cat(paste("I:", "\n", sep="\t"))
  # target person
  cat(paste("(targPerson)", sep="\t"))
  print(white_predom_fem_pretrain[i,], sep = "\t", quote = FALSE, row.names = FALSE)
  
  # hair length 
  cat(paste("(hairLength)", sep="\t"))
  print(hairLength[2,], sep = "\t", quote = FALSE, row.names = FALSE)
  
  # feminine facial features 
  cat(paste("(femFacFeat)", sep="\t"))
  print(femFacFeat[2,], sep = "\t", quote = FALSE, row.names = FALSE)
  
  # skin color
  cat(paste("(skinColor)", sep="\t"))
  print(skinColor[2,], sep = "\t", quote = FALSE, row.names = FALSE)
  
  # OUTPUT
  cat(paste("T:", "\n", sep="\t"))
  
  cat(paste("(femCatOUT)", sep="\t"))
  print(femCat[2,], sep = "\t", quote = FALSE, row.names = FALSE)
  
  cat(paste(";", sep="\t"))
  cat("\n")
  l = l+1
}


# name pred white features
for(i in 1:nrow(white_predom_fem_pretrain)){
  cat(paste("name: NamePredWhiteFemFeat", k, "\n", sep=""))
  cat(paste("I:", "\n", sep="\t"))
  
  cat(paste("(femCat)", sep="\t"))
  print(femCat[2,], sep = "\t", quote = FALSE, row.names = FALSE)
  
  # OUTPUT
  cat(paste("T:", "\n", sep="\t"))
  
  # target person
  cat(paste("(targPersonOUT)", sep="\t"))
  print(white_predom_fem_pretrain[i,], sep = "\t", quote = FALSE, row.names = FALSE)
  
  # hair length 
  cat(paste("(hairLengthOUT)", sep="\t"))
  print(hairLength[2,], sep = "\t", quote = FALSE, row.names = FALSE)
  
  # feminine facial features 
  cat(paste("(femFacFeatOUT)", sep="\t"))
  print(femFacFeat[2,], sep = "\t", quote = FALSE, row.names = FALSE)
  
  # skin color
  cat(paste("(skinColorOUT)", sep="\t"))
  print(skinColor[2,], sep = "\t", quote = FALSE, row.names = FALSE)
  
  cat(paste(";", sep="\t"))
  cat("\n")
  
  k = k+1
}



# features predicting femCat
for(i in 1:nrow(black_predom_fem_pretrain)){
  cat(paste("name: BlackFemFeatPredName", m, "\n", sep=""))
  cat(paste("I:", "\n", sep="\t"))
  # target person
  cat(paste("(targPerson)", sep="\t"))
  print(black_predom_fem_pretrain[i,], sep = "\t", quote = FALSE, row.names = FALSE)
  
  # hair length 
  cat(paste("(hairLength)", sep="\t"))
  print(hairLength[1,], sep = "\t", quote = FALSE, row.names = FALSE)
  
  # feminine facial features 
  cat(paste("(femFacFeat)", sep="\t"))
  print(femFacFeat[1,], sep = "\t", quote = FALSE, row.names = FALSE)
  
  # skin color
  cat(paste("(skinColor)", sep="\t"))
  print(skinColor[1,], sep = "\t", quote = FALSE, row.names = FALSE)
  
  # OUTPUT
  cat(paste("T:", "\n", sep="\t"))
  
  cat(paste("(femCatOUT)", sep="\t"))
  print(femCat[1,], sep = "\t", quote = FALSE, row.names = FALSE)
  
  cat(paste(";", sep="\t"))
  cat("\n")
  
  m = m+1
}


# name pred white features
for(i in 1:nrow(black_predom_fem_pretrain)){
  cat(paste("name: NamePredBlackFemFeat", n, "\n", sep=""))
  cat(paste("I:", "\n", sep="\t"))
  
  cat(paste("(femCat)", sep="\t"))
  print(femCat[2,], sep = "\t", quote = FALSE, row.names = FALSE)
  
  # OUTPUT
  cat(paste("T:", "\n", sep="\t"))
  
  # target person
  cat(paste("(targPersonOUT)", sep="\t"))
  print(black_predom_fem_pretrain[i,], sep = "\t", quote = FALSE, row.names = FALSE)
  
  # hair length 
  cat(paste("(hairLengthOUT)", sep="\t"))
  print(hairLength[1,], sep = "\t", quote = FALSE, row.names = FALSE)
  
  # feminine facial features 
  cat(paste("(femFacFeatOUT)", sep="\t"))
  print(femFacFeat[1,], sep = "\t", quote = FALSE, row.names = FALSE)
  
  # skin color
  cat(paste("(skinColorOUT)", sep="\t"))
  print(skinColor[1,], sep = "\t", quote = FALSE, row.names = FALSE)
  
  cat(paste(";", sep="\t"))
  cat("\n")
  
  n = n+1
}



# features predicting femCat
for(i in 1:nrow(black_predom_male_pretrain)){
  cat(paste("name: BlackMaleFeatPredName", o, "\n", sep=""))
  cat(paste("I:", "\n", sep="\t"))
  # target person
  cat(paste("(targPerson)", sep="\t"))
  print(black_predom_male_pretrain[i,], sep = "\t", quote = FALSE, row.names = FALSE)
  
  # hair length 
  cat(paste("(hairLength)", sep="\t"))
  print(hairLength[1,], sep = "\t", quote = FALSE, row.names = FALSE)
  
  # feminine facial features 
  cat(paste("(femFacFeat)", sep="\t"))
  print(femFacFeat[1,], sep = "\t", quote = FALSE, row.names = FALSE)
  
  # skin color
  cat(paste("(skinColor)", sep="\t"))
  print(skinColor[1,], sep = "\t", quote = FALSE, row.names = FALSE)
  
  # OUTPUT
  cat(paste("T:", "\n", sep="\t"))
  
  cat(paste("(femCatOUT)", sep="\t"))
  print(femCat[1,], sep = "\t", quote = FALSE, row.names = FALSE)
  
  cat(paste(";", sep="\t"))
  cat("\n")
  
  o = o+1
}


# name pred white features
for(i in 1:nrow(black_predom_male_pretrain)){
  cat(paste("name: NamePredBlackMaleFeat", p, "\n", sep=""))
  cat(paste("I:", "\n", sep="\t"))
  
  cat(paste("(femCat)", sep="\t"))
  print(femCat[1,], sep = "\t", quote = FALSE, row.names = FALSE)
  
  # OUTPUT
  cat(paste("T:", "\n", sep="\t"))
  
  # target person
  cat(paste("(targPersonOUT)", sep="\t"))
  print(black_predom_male_pretrain[i,], sep = "\t", quote = FALSE, row.names = FALSE)
  
  # hair length 
  cat(paste("(hairLengthOUT)", sep="\t"))
  print(hairLength[1,], sep = "\t", quote = FALSE, row.names = FALSE)
  
  # feminine facial features 
  cat(paste("(femFacFeatOUT)", sep="\t"))
  print(femFacFeat[1,], sep = "\t", quote = FALSE, row.names = FALSE)
  
  # skin color
  cat(paste("(skinColorOUT)", sep="\t"))
  print(skinColor[1,], sep = "\t", quote = FALSE, row.names = FALSE)
  
  cat(paste(";", sep="\t"))
  cat("\n")
  
  p = p+1
}
sink()






##########
## TEST ##
##########
l1 = 1 
k1 = 1
m1 = 1
n1 = 1
o1 = 1
p1 = 1

sink('test.ex')
cat(paste("defI:-", "\n", sep=""))
cat(paste("defT:-", "\n", sep=""))
cat(paste(";", "\n", sep=""))
# features predicting femCat
for(i in 1:nrow(white_predom_fem_test)){
  cat(paste("name: WhiteFemFeatPredName", l1, "\n", sep=""))
  cat(paste("I:", "\n", sep="\t"))
  # target person
  cat(paste("(targPerson)", sep="\t"))
  print(white_predom_fem_test[i,], sep = "\t", quote = FALSE, row.names = FALSE)
  
  # hair length 
  cat(paste("(hairLength)", sep="\t"))
  print(hairLength[2,], sep = "\t", quote = FALSE, row.names = FALSE)
  
  # feminine facial features 
  cat(paste("(femFacFeat)", sep="\t"))
  print(femFacFeat[2,], sep = "\t", quote = FALSE, row.names = FALSE)
  
  # skin color
  cat(paste("(skinColor)", sep="\t"))
  print(skinColor[2,], sep = "\t", quote = FALSE, row.names = FALSE)
  
  # OUTPUT
  cat(paste("T:", "\n", sep="\t"))
  
  cat(paste("(femCatOUT)", sep="\t"))
  print(femCat[2,], sep = "\t", quote = FALSE, row.names = FALSE)
  
  cat(paste(";", sep="\t"))
  cat("\n")
  l1 = l1+1
}


# name pred white features
for(i in 1:nrow(white_predom_fem_test)){
  cat(paste("name: NamePredWhiteFemFeat", k1, "\n", sep=""))
  cat(paste("I:", "\n", sep="\t"))
  
  cat(paste("(femCat)", sep="\t"))
  print(femCat[2,], sep = "\t", quote = FALSE, row.names = FALSE)
  
  # OUTPUT
  cat(paste("T:", "\n", sep="\t"))
  
  # target person
  cat(paste("(targPersonOUT)", sep="\t"))
  print(white_predom_fem_test[i,], sep = "\t", quote = FALSE, row.names = FALSE)
  
  # hair length 
  cat(paste("(hairLengthOUT)", sep="\t"))
  print(hairLength[2,], sep = "\t", quote = FALSE, row.names = FALSE)
  
  # feminine facial features 
  cat(paste("(femFacFeatOUT)", sep="\t"))
  print(femFacFeat[2,], sep = "\t", quote = FALSE, row.names = FALSE)
  
  # skin color
  cat(paste("(skinColorOUT)", sep="\t"))
  print(skinColor[2,], sep = "\t", quote = FALSE, row.names = FALSE)
  
  cat(paste(";", sep="\t"))
  cat("\n")
  
  k1 = k1+1
}



# features predicting femCat
for(i in 1:nrow(black_predom_fem_test)){
  cat(paste("name: BlackFemFeatPredName", m1, "\n", sep=""))
  cat(paste("I:", "\n", sep="\t"))
  # target person
  cat(paste("(targPerson)", sep="\t"))
  print(black_predom_fem_test[i,], sep = "\t", quote = FALSE, row.names = FALSE)
  
  # hair length 
  cat(paste("(hairLength)", sep="\t"))
  print(hairLength[1,], sep = "\t", quote = FALSE, row.names = FALSE)
  
  # feminine facial features 
  cat(paste("(femFacFeat)", sep="\t"))
  print(femFacFeat[1,], sep = "\t", quote = FALSE, row.names = FALSE)
  
  # skin color
  cat(paste("(skinColor)", sep="\t"))
  print(skinColor[1,], sep = "\t", quote = FALSE, row.names = FALSE)
  
  # OUTPUT
  cat(paste("T:", "\n", sep="\t"))
  
  cat(paste("(femCatOUT)", sep="\t"))
  print(femCat[1,], sep = "\t", quote = FALSE, row.names = FALSE)
  
  cat(paste(";", sep="\t"))
  cat("\n")
  
  m1 = m1+1
}


# name pred white features
for(i in 1:nrow(black_predom_fem_test)){
  cat(paste("name: NamePredBlackFemFeat", n1, "\n", sep=""))
  cat(paste("I:", "\n", sep="\t"))
  
  cat(paste("(femCat)", sep="\t"))
  print(femCat[1,], sep = "\t", quote = FALSE, row.names = FALSE)
  
  # OUTPUT
  cat(paste("T:", "\n", sep="\t"))
  
  # target person
  cat(paste("(targPersonOUT)", sep="\t"))
  print(black_predom_fem_test[i,], sep = "\t", quote = FALSE, row.names = FALSE)
  
  # hair length 
  cat(paste("(hairLengthOUT)", sep="\t"))
  print(hairLength[1,], sep = "\t", quote = FALSE, row.names = FALSE)
  
  # feminine facial features 
  cat(paste("(femFacFeatOUT)", sep="\t"))
  print(femFacFeat[1,], sep = "\t", quote = FALSE, row.names = FALSE)
  
  # skin color
  cat(paste("(skinColorOUT)", sep="\t"))
  print(skinColor[1,], sep = "\t", quote = FALSE, row.names = FALSE)
  
  cat(paste(";", sep="\t"))
  cat("\n")
  
  n1 = n1+1
}



# features predicting femCat
for(i in 1:nrow(black_predom_male_test)){
  cat(paste("name: BlackMaleFeatPredName", o1, "\n", sep=""))
  cat(paste("I:", "\n", sep="\t"))
  # target person
  cat(paste("(targPerson)", sep="\t"))
  print(black_predom_male_test[i,], sep = "\t", quote = FALSE, row.names = FALSE)
  
  # hair length 
  cat(paste("(hairLength)", sep="\t"))
  print(hairLength[1,], sep = "\t", quote = FALSE, row.names = FALSE)
  
  # feminine facial features 
  cat(paste("(femFacFeat)", sep="\t"))
  print(femFacFeat[1,], sep = "\t", quote = FALSE, row.names = FALSE)
  
  # skin color
  cat(paste("(skinColor)", sep="\t"))
  print(skinColor[1,], sep = "\t", quote = FALSE, row.names = FALSE)
  
  # OUTPUT
  cat(paste("T:", "\n", sep="\t"))
  
  cat(paste("(femCatOUT)", sep="\t"))
  print(femCat[1,], sep = "\t", quote = FALSE, row.names = FALSE)
  
  cat(paste(";", sep="\t"))
  cat("\n")
  
  o1 = o1+1
}


# name pred white features
for(i in 1:nrow(black_predom_male_test)){
  cat(paste("name: NamePredBlackMaleFeat", p1, "\n", sep=""))
  cat(paste("I:", "\n", sep="\t"))
  
  cat(paste("(femCat)", sep="\t"))
  print(femCat[1,], sep = "\t", quote = FALSE, row.names = FALSE)
  
  # OUTPUT
  cat(paste("T:", "\n", sep="\t"))
  
  # target person
  cat(paste("(targPersonOUT)", sep="\t"))
  print(black_predom_male_test[i,], sep = "\t", quote = FALSE, row.names = FALSE)
  
  # hair length 
  cat(paste("(hairLengthOUT)", sep="\t"))
  print(hairLength[1,], sep = "\t", quote = FALSE, row.names = FALSE)
  
  # feminine facial features 
  cat(paste("(femFacFeatOUT)", sep="\t"))
  print(femFacFeat[1,], sep = "\t", quote = FALSE, row.names = FALSE)
  
  # skin color
  cat(paste("(skinColorOUT)", sep="\t"))
  print(skinColor[1,], sep = "\t", quote = FALSE, row.names = FALSE)
  
  cat(paste(";", sep="\t"))
  cat("\n")
  
  p1 = p1+1
}
sink()

